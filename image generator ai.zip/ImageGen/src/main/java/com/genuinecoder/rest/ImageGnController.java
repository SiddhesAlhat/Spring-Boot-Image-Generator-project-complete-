package com.genuinecoder.rest;

import javax.imageio.ImageReader;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.image.ImagePrompt;
import org.springframework.ai.image.ImageResponse;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.OpenAiImageModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

//@RestController
//
//public class ImageGnController 
//{	
//	private ChatClient chatClient;
//	private  OpenAiImageModel openAiImageModel;
//	
//	  public ImageGnController(OpenAiChatModel chatModel,OpenAiImageModel openAiImageModel ) 
//	  {
//		  this.chatClient = ChatClient.create(chatModel);
//		  this.openAiImageModel =openAiImageModel ;
//
//	  }
//	
//	  @GetMapping("/api/get-image")
//	  public String generateImage(@RequestParam String query) {
//	  	try {
//	  		ImagePrompt imagePrompt = new ImagePrompt(query);
//	  		ImageResponse imageResponse = openAiImageModel.call(imagePrompt);
//	  		return imageResponse.getResult().getOutput().getUrl();
//	  	} catch (Exception e) {
//	  		return "Failed to generate image: " + e.getMessage();
//	  	}
//	  }
//}

@RestController
@RequestMapping("/api/image")
public class ImageGnController {

    private final String ACCESS_KEY = "WGJ3TAuZogaCvgMdQokAyDbsevKcLU-0IKxkFIzHpRs" ;
    @GetMapping
    public String getImage(@RequestParam String query) {
        String url = "https://api.unsplash.com/search/photos?query=" + query +
                     "&per_page=1&client_id=" + ACCESS_KEY;

        RestTemplate restTemplate = new RestTemplate();
        String response = restTemplate.getForObject(url, String.class);

        JSONObject json = new JSONObject(response);
        JSONArray results = json.getJSONArray("results");

        if (results.isEmpty()) {
            return "No image found for query: " + query;
        }
        
        String imageUrl = results.getJSONObject(0)
                                 .getJSONObject("urls")
                                 .getString("regular");

        return "image-gen.html";
    }
}

